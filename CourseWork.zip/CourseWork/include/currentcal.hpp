
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#include <chrono>
#include <ctime>
#include <iomanip>
#include <iostream>
#include <stdexcept>
#include <string>

#ifndef __CURRENTCALHPP
#define __CURRENTCALHPP
#include "/usr/include/linux/can.h"
#include "candata.h"

#define RPM_SEVEN_HUNDRED 700
#define TORQUE_FIFTY 50
#define RPM_SIX_HUNDRED 600
#define TORQUE_EIGHTY_FIVE 85
#define RPM_FIVE_HUNDRED 500
#define TORQUE_HUNDRED 100
#define RPM_FOUR_HUNDRED 400
#define TORQUE_ONE_TWENTY 120
#define RPM_THREE_HUNDRED 300
#define TORQUE_ONE_FIFTY 150
#define HUNDRED 100
#define MOTOR_q 0.879
#define ELECTROMAGNETIC_FIELD_FACTOR_b 0.6721
#define LOW_BATTERY_LIMIT_TORQUE 20
#define BATTERY_LOW_VOLTAGE 2.8
#define MAX_ITERATIONS 1000
#define ZER0_POINT_ZERO 0.0
typedef struct candata_motor_current_t Struct;
#pragma once
/*! \class CanFrame
 * \brief This is the main class that holds methods for 
 * torque frame,wheel speed frame,battery frame and current calculator
 * ,variables which hold the respective values recied from the can,
 * Getter and Setter functions for the same
 * 
 * 
*/
class CanFrame
{
      private:
	double front_trq;      /**< front torque value in N-m. */
	double rear_trq;       /**< Rear torque value in N-m. */
	double fl_wheel_speed; /**< front left wheel speed value in rpm. */
	double fr_wheel_speed; /**< front right wheel speed value in rpm. */
	double rl_wheel_speed; /**< rear left wheel speed value in rpm. */
	double rr_wheel_speed; /**< rear right wheel speed value in rpm. */
	double voltage;	       /**< Battery voltage. */

      public:
	void torque_frame(const can_frame frame);
	void wheel_speeds_frame(const can_frame frame);
	void battery_frame(const can_frame frame);
	Struct currentcal(void);

	//setter
	void setFront_trq(double Sfronttrq) /**< set the front torque value. */
	{
		front_trq = Sfronttrq;
	}
	void setRear_trq(double Sreartrq) /**< set the rear torque value. */
	{
		rear_trq = Sreartrq;
	}
	void setFl_wheel_speed(double Sflwheelspeed) /**< set the front left wheel speed. */
	{
		fl_wheel_speed = Sflwheelspeed;
	}
	void setFr_wheel_speed(double Sfrwheelspeed) /**< set the front right wheel speed. */
	{
		fr_wheel_speed = Sfrwheelspeed;
	}
	void setRl_wheel_speed(double Srlwheelspeed) /**< set the rear left wheel speed. */
	{
		rl_wheel_speed = Srlwheelspeed;
	}
	void setRr_wheel_speed(double Srrwheelspeed) /**< set the rear right wheel speed. */
	{
		rr_wheel_speed = Srrwheelspeed;
	}
	void setVoltage(double Svoltage) /**< set the Battery voltage value. */
	{
		voltage = Svoltage;
	}
	//getter
	double getFront_trq() /**< get the front torque value. */
	{
		return front_trq;
	}
	double getRear_trq() /**< get the rear torque value. */
	{
		return rear_trq;
	}
	double getFl_wheel_speed() /**< get the front left wheel speed. */
	{
		return fl_wheel_speed;
	}
	double getFr_wheel_speed() /**< get the front right wheel speed. */
	{
		return fr_wheel_speed;
	}
	double getRl_wheel_speed() /**< get the rear left wheel speed. */
	{
		return rl_wheel_speed;
	}
	double getRr_wheel_speed() /**< get the rear right wheel speed. */
	{
		return rr_wheel_speed;
	}
	double getVoltage() /**< get the Battery voltage value. */
	{
		return voltage;
	}
};

inline CanFrame Canobj;	 ///**< CanFrame Canobject. */

#endif