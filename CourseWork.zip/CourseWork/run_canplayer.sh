#!/bin/sh

# create vcan0 device
#sudo apt-get update
sudo apt-get -y install can-utils
echo "Setting VCAN0 up"
sudo modprobe can
sudo modprobe vcan
sudo ip link add dev vcan0 type vcan
sudo ip link set up vcan0


cd docs
canplayer -I candump.log vcan0=vcan0

