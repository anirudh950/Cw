#!/bin/sh

# get the kernal module here
sudo apt-get install -y linux-modules-extra-$(uname -r)
echo "Installing Linux Modules"

# create vcan0 device
sudo apt-get update
sudo apt-get -y install can-utils
echo "Setting VCAN0 up"
sudo modprobe can
sudo modprobe vcan
sudo ip link add dev vcan0 type vcan
sudo ip link set up vcan0

#Clang Formatting
echo "Clang Formatting"
sudo apt install clang
sudo apt install clang-format
clang-format -i ./src/currentcal.cpp
clang-format  -i  ./src/main.cpp
clang-format -i ./include/currentcal.hpp

#Clang Tidy
echo "Clang Tidy Checks"
sudo apt install clang-tidy
clang-tidy --checks='clang-analyzer-*' ./include/currentcal.hpp
clang-tidy --checks='clang-analyzer-*' ./src/currentcal.cpp
clang-tidy --checks='clang-analyzer-*' ./src/main.cpp

#build directory
echo "Building the Binaries"
cmake .
cmake --build .
cp -r src_autogen/candata.h include/

#Doxygen
cmake --build . --target docs

#unittest
cd Testing/bin
./test_currentcal
cd ../..


