/* Include the unit testing libraries */
#define CATCH_CONFIG_MAIN
#include <catch.hpp>

/* Include the code that we plan to test */
#include "currentcal.hpp"
#include "candata.h"
#include "../include/currentcal.hpp"

extern CanFrame Canobj;


//410550
TEST_CASE( "Normal CAN values" )
{   
    Struct Ivalcal,Ivalrec;

    //calculated current
     Ivalcal.front_current = 23379;
     Ivalcal.rear_current = 17627;
     //setter random values
     Canobj.setFront_trq(640);
     
     Canobj.setFl_wheel_speed(59.4);
     Canobj.setFr_wheel_speed(47.3);
     Canobj.setRl_wheel_speed(57.5);
     Canobj.setRr_wheel_speed(44.6);
     Canobj.setVoltage(7.157);
    

    WHEN( "negative rear torque" )
    {   
        Canobj.setRear_trq(-567);
        Ivalrec = Canobj.currentcal();
        INFO( "front current");
        REQUIRE( Ivalrec.front_current == Ivalcal.front_current );

        INFO( "rear current");
        REQUIRE( Ivalrec.rear_current == Ivalcal.rear_current );
        Canobj.setRear_trq(0);
    }

}

/* Test case 2
Fastest wheel(rpm) | Max allowed torque (Nm)
*/

TEST_CASE( "CAN torque limit tests" )
{   
    Struct Ivalcal,Ivalrec;

   
    WHEN( "rpm>300 and torque >150" )
    {   
        //calculated current
        Ivalcal.front_current = 9750;
        Ivalcal.rear_current = 9753;
        //setter random values
        Canobj.setFront_trq(459);
        Canobj.setRear_trq(157);
        Canobj.setFl_wheel_speed(329.8);
        Canobj.setFr_wheel_speed(330.1);
        Canobj.setRl_wheel_speed(329.8);
        Canobj.setRr_wheel_speed(330.2);
        Canobj.setVoltage(5.153);
        Ivalrec = Canobj.currentcal();
        INFO( "front current");
        REQUIRE( Ivalrec.front_current == Ivalcal.front_current );

        INFO( "rear current");
        REQUIRE( Ivalrec.rear_current == Ivalcal.rear_current );
        Canobj.setRear_trq(0);
    }

    WHEN( "rpm>400 and torque >120 test" )
    {   
        //calculated current
        Ivalcal.front_current = 7604;
        Ivalcal.rear_current = 7606;
        //setter random values
        Canobj.setFront_trq(348);
        Canobj.setRear_trq(128);
        Canobj.setFl_wheel_speed(400.8);
        Canobj.setFr_wheel_speed(401.1);
        Canobj.setRl_wheel_speed(400.8);
        Canobj.setRr_wheel_speed(401.2);
        Canobj.setVoltage(5.135);
        Ivalrec = Canobj.currentcal();
        INFO( "front current");
        REQUIRE( Ivalrec.front_current == Ivalcal.front_current );

        INFO( "rear current");
        REQUIRE( Ivalrec.rear_current == Ivalcal.rear_current );
        Canobj.setRear_trq(0);
    }
}

//current limiting test case

TEST_CASE( "Low voltage Torque limiting" )
{   
    Struct Ivalcal,Ivalrec;

    //calculated current
     Ivalcal.front_current = 87;
     Ivalcal.rear_current = 84;
     //setting random values
     Canobj.setFront_trq(138);
     Canobj.setRear_trq(-98);
     Canobj.setFl_wheel_speed(47.3);
     Canobj.setFr_wheel_speed(59.5);
     Canobj.setRl_wheel_speed(44.6);
     Canobj.setRr_wheel_speed(57.4);
     Canobj.setVoltage(2.095);
    

    WHEN( "negative rear torque" )
    {   
        Ivalrec = Canobj.currentcal();
        INFO( "front current");
        REQUIRE( Ivalrec.front_current == Ivalcal.front_current );

        INFO( "rear current");
        REQUIRE( Ivalrec.rear_current == Ivalcal.rear_current );
        Canobj.setRear_trq(0);
    }
}


TEST_CASE( "Front negative torque" )
{   
    Struct Ivalcal,Ivalrec;

    //calculated current
     Ivalcal.front_current = -18821;
     Ivalcal.rear_current = -16179;
     //setter random values
     Canobj.setFront_trq(-881);
     Canobj.setRear_trq(1380);
     Canobj.setFl_wheel_speed(31.3);
     Canobj.setFr_wheel_speed(31.5);
     Canobj.setRl_wheel_speed(31.1);
     Canobj.setRr_wheel_speed(31.3);
     Canobj.setVoltage(3.627);
    

    WHEN( "negative rear torque" )
    {   
        Ivalrec = Canobj.currentcal();
        INFO( "front current");
        REQUIRE( Ivalrec.front_current == Ivalcal.front_current );

        INFO( "rear current");
        REQUIRE( Ivalrec.rear_current == Ivalcal.rear_current );
        Canobj.setRear_trq(0);
    }
}
