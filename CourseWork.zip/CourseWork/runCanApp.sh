#!/bin/sh

cd apps
./CanApp