COURSE WORK 716EECEM 

This demonstrated hoe to build the application and run successfully 

after clone the Coursework repo to local Directory


step 1: run build.sh  Script to install and generate required file 
 and following are the output 
  1.generates application CanApp in apps/ Directory
  2.checks for clang-tidy checks = llvm-include-order (static Analysys)
  3.clang-format /src/currentcal.cpp /src/main.cpp /include/currentcal.hpp
  4.generate candbc files into /src_autogen
  5.setup the vcan0
  6.Automatic unit testing
  6.build Doxygen html docs
  
         note: Getting error here in unitTest Error on CODIO VM  ,working on ubuntu 20.04 and 22.04 LTS
         ERROR:
          /home/ubuntu/CourseWork/Testing/helper/catch/catch.hpp:7441:33: error: variable length   array   declaration not allowed at file scope [clang-diagnostic-error]
           char FatalConditionHandler::altStackMem[SIGSTKSZ] = {};
                                       ^
           1 warning and 1 error generated.
           Error while processing /home/ubuntu/CourseWork/Testing/test_currentcal.cpp.
           Suppressed 1 warnings (1 in non-user code).
           Use -header-filter=.* to display errors from all non-system headers. Use -system-headers to display errors from system headers as well.
           Found compiler error(s).
           gmake[2]: *** [Testing/CMakeFiles/test_currentcal.dir/build.make:76: Testing/CMakeFiles/test_currentcal.dir/test_currentcal.cpp.o] Error 1
           gmake[1]: *** [CMakeFiles/Makefile2:173: Testing/CMakeFiles/test_currentcal.dir/all] Error 2
       
Step2:Run Script run_canplayer.sh to Simulate the CAN DATA 


Step3:open a new terminal in same Directory and Run Script runCanApp.sh to see the Application Dumps of torque,limitvalues,speed(rpm),Battery voltage

step4:open a new terminal in same Directory and Run Script candump320.sh to see the vcan0 Dumps of cuurent values as can messeges.

step5:To check the Documatetation Genearted go to docs/html/ and open main_8cpp.html in any webbrowser(chrome recommended) and check the Doxygen API notes