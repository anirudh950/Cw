# Course Work   716EECEM                     {#mainpage}

This is the documentation for Course Work CW1 (CAN Implemetation)

This Program Recieves the CAN Frames from ID 0x521,0x525,0x526 required to calculate the Motor current
send the same on the CAN ID 0x320 
The main features of the software are

1. Decodes the Respective CAN frame into usable data

2. Apply the Algorithm to  limit the Torque during different rpm conditions

3. Apply the Algorithm to limit the Torque during low battery conditions

4. calculate the safe current after the safe limits
 
5. encode the current into the CAN frame and send it over to the VCAN0