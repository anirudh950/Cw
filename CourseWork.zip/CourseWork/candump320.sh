#!/bin/sh

candump vcan0,320:ffff