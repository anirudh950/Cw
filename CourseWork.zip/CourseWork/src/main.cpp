/**
* @file main.cpp
* 
*
*@brief  
*main.cpp Recieves the CAN Frames from ID 521,525,526 required to calculate the Motor current
*send the same on the CAN ID 0x320
* 
**/

#include "../include/can_wrap.hpp"
#include "../include/candata.h"
#include "../include/currentcal.hpp"

using namespace std;
using can::operator<<;

/** 
*  Decode the torque frame,update it to CanFrame object
* and check the range of data
* @param can_frame frame consists of the Torque raw data
*  
*  @return void      
**/
void CanFrame::torque_frame(const can_frame frame)
{
	candata_ai_drive_request_t data;
	candata_ai_drive_request_unpack(&data, frame.data, frame.can_dlc);

	if (!candata_ai_drive_request_front_trq_request_is_in_range(
		data.front_trq_request))
		throw std::out_of_range("front trq request");

	if (!candata_ai_drive_request_rear_trq_request_is_in_range(
		data.rear_trq_request))
		throw std::out_of_range("rear trq request");

	const double front =
	    candata_ai_drive_request_front_trq_request_decode(data.front_trq_request);
	const double rear =
	    candata_ai_drive_request_rear_trq_request_decode(data.rear_trq_request);

	if (!front && !rear)
		std::cout << "torque request NULL" << std::endl;
	else {
		Canobj.front_trq = front;

		Canobj.rear_trq = rear;

		std::cout << std::endl;
	}
}
/** 
*  Decode the wheel speed frame,update it to CanFrame object
* and check the range of data
* @param can_frame frame consists of the Wheel speed  raw data
*  
*  @return void      
**/
void CanFrame::wheel_speeds_frame(const can_frame frame)
{

	auto start = std::chrono::steady_clock::now();
	candata_vcu_wheel_speeds_t data;
	candata_vcu_wheel_speeds_unpack(&data, frame.data, frame.can_dlc);

	if (!candata_vcu_wheel_speeds_fl_wheel_speed_is_in_range(data.fl_wheel_speed))
		throw std::out_of_range("front left wheel speed");

	if (!candata_vcu_wheel_speeds_fr_wheel_speed_is_in_range(data.fr_wheel_speed))
		throw std::out_of_range("front right wheel speed");

	if (!candata_vcu_wheel_speeds_rl_wheel_speed_is_in_range(data.rl_wheel_speed))
		throw std::out_of_range("rear left wheel speed");

	if (!candata_vcu_wheel_speeds_rr_wheel_speed_is_in_range(data.rr_wheel_speed))
		throw std::out_of_range("rear right wheel speed");

	const double flwheel_speed =
	    candata_vcu_wheel_speeds_fl_wheel_speed_decode(data.fl_wheel_speed);
	const double frwheel_speed =
	    candata_vcu_wheel_speeds_fr_wheel_speed_decode(data.fr_wheel_speed);
	const double rlwheel_speed =
	    candata_vcu_wheel_speeds_rl_wheel_speed_decode(data.rl_wheel_speed);
	const double rrwheel_speed =
	    candata_vcu_wheel_speeds_rr_wheel_speed_decode(data.rr_wheel_speed);

	if (!flwheel_speed && !frwheel_speed && !rlwheel_speed && !rrwheel_speed)
		std::cout << "wheel speed request NULL" << std::endl;
	else {
		Canobj.fl_wheel_speed = flwheel_speed;
		Canobj.fr_wheel_speed = frwheel_speed;
		Canobj.rl_wheel_speed = rlwheel_speed;
		Canobj.rr_wheel_speed = rrwheel_speed;
	}
}
/** 
*  Decode the battery voltage frame,update it to CanFrame object
* and check the range of data
* @param can_frame frame consists of the voltage raw data
*  
*  @return void      
**/
void CanFrame::battery_frame(const can_frame frame)
{

	candata_vcu_battery_t data;
	candata_vcu_battery_unpack(&data, frame.data, frame.can_dlc);

	if (!candata_vcu_battery_voltage_is_in_range(data.voltage))
		throw std::out_of_range("Battery Voltage");

	const double batteryvoltage =
	    candata_vcu_battery_voltage_decode(data.voltage);

	Canobj.voltage = batteryvoltage;
}
/** 
* recieves the frame and allocates the frames to repective Decode functions 
* 
* @param can_frame frame consists of the CAN messege
*
* @param candata_motor_current_t calculated motor front and rear current 
*
* @return void      
**/
void process_frame(const can_frame frame, Struct *mtr_currentptr)
{
	Struct Ival;
	switch (frame.can_id) {
	case CANDATA_AI_DRIVE_REQUEST_FRAME_ID:
		Canobj.torque_frame(frame);
		break;
	case CANDATA_VCU_WHEEL_SPEEDS_FRAME_ID:
		Canobj.wheel_speeds_frame(frame);
		break;
	case CANDATA_VCU_BATTERY_FRAME_ID:
		Canobj.battery_frame(frame);
		break;

	default:
		throw std::runtime_error(
		    std::string("No Valid CAN ID Found for current Caculation"));
		throw std::runtime_error(std::string("Please check the CAN Socket"));
		break;
	}

	Ival = Canobj.currentcal();
	mtr_currentptr->front_current = Ival.front_current;
	mtr_currentptr->rear_current = Ival.rear_current;
}

/** 
* recieves the CAN frame messege call methods to decode 
* and calculate current and send the current messege on CAN
* 
* @param argc character parameters for commandline operations
*
* @param argv[] string paramter for command line operations 
*
* @return NULL     
**/
int main(int argc, char *argv[])
{
	const std::string canChannel = "vcan0";
	Struct mtr_current;
	Struct *mtr_currentptr;
	mtr_currentptr = &mtr_current;
	candata_motor_current_t motorIval;

	try {
		const int canSocket = can::connect(canChannel);

		do {
			const can_frame recieve_frame = can::read(canSocket);
			process_frame(recieve_frame, mtr_currentptr);
			can_frame send_frame;
			std::memset(&send_frame, 0, sizeof(send_frame));
			send_frame.can_id = CANDATA_MOTOR_CURRENT_FRAME_ID;
			send_frame.can_dlc = CANDATA_MOTOR_CURRENT_LENGTH;
			motorIval.front_current = mtr_currentptr->front_current;
			motorIval.rear_current = mtr_currentptr->rear_current;
			candata_motor_current_pack(send_frame.data, &motorIval,
						   send_frame.can_dlc);
			// std::cout << send_frame << std::endl;
			can::write(canSocket, send_frame);
		} while (!(canSocket < 0));

		can::close(canSocket);
	} catch (const std::exception &e) {
		std::cerr << e.what() << std::endl;
	}

	return 0;
}
