/**@file currentcal.cpp
* 
*
*@brief  Current Calculation with Algortim to limit the torque 
* This contains the protoype function to Apply torque Limiting
* Algorithm and calculate the rear and front currents
* required for the motor  
* 
*/

#ifndef CUR_CAL
#define CUR_CAL
#include "../include/currentcal.hpp"

/** 
* 
*  Currentcal function calculates the front and rear current 
*
*  @param CanFrame Canobj CanFrame type CAN object which holds all parameters required for current calculation
*   fl_wheel_speed(front left wheel speed) ,
*   fr_wheel_speed(front right wheel speed),
*   rl_wheel_speed(rear left wheel speed),
*   rr_wheel_speed (rear right wheel speed),
*   front_trq (front wheel torque),
*   rear_trq (rear wheel torque),
*   voltage (battery voltage)
*  
*  @return candata_motor_current_t  holds front motor current and rear motor current      
**/

Struct CanFrame::currentcal()
{
	Struct Ival;
	double max_front_wheel_speed = Canobj.fl_wheel_speed > Canobj.fr_wheel_speed
					   ? Canobj.fl_wheel_speed
					   : Canobj.fr_wheel_speed;
	double max_rear_wheel_speed = Canobj.rl_wheel_speed > Canobj.rr_wheel_speed
					  ? Canobj.rl_wheel_speed
					  : Canobj.rr_wheel_speed;
	double temp_front_trq = ZER0_POINT_ZERO; /**< temporary the front torque value. */
	double temp_rear_trq = ZER0_POINT_ZERO;	 /**< temporary the rear torque value. */

	// front torque limit algorithm
	//>700 rpm
	temp_front_trq = (max_front_wheel_speed > RPM_SEVEN_HUNDRED && Canobj.front_trq <= TORQUE_FIFTY)
			     ? Canobj.front_trq
			     : TORQUE_FIFTY;
	//>600 rpm
	if (max_front_wheel_speed <= RPM_SEVEN_HUNDRED) {
		temp_front_trq = (max_front_wheel_speed > RPM_SIX_HUNDRED && Canobj.front_trq <= TORQUE_EIGHTY_FIVE)
				     ? Canobj.front_trq
				     : TORQUE_EIGHTY_FIVE;
	}
	//>500 rpm
	if (max_front_wheel_speed <= RPM_SIX_HUNDRED) {
		temp_front_trq = (max_front_wheel_speed > RPM_FIVE_HUNDRED && Canobj.front_trq <= TORQUE_HUNDRED)
				     ? Canobj.front_trq
				     : TORQUE_HUNDRED;
	}
	//>400 rpm
	if (max_front_wheel_speed <= RPM_FIVE_HUNDRED) {
		temp_front_trq = (max_front_wheel_speed > RPM_FOUR_HUNDRED && Canobj.front_trq <= TORQUE_ONE_TWENTY)
				     ? Canobj.front_trq
				     : TORQUE_ONE_TWENTY;
	}
	//>300
	if (max_front_wheel_speed <= RPM_FOUR_HUNDRED) {
		temp_front_trq = (max_front_wheel_speed > RPM_THREE_HUNDRED && Canobj.front_trq <= TORQUE_ONE_FIFTY)
				     ? Canobj.front_trq
				     : TORQUE_ONE_FIFTY;
	}
	//<300 rpm
	if (max_front_wheel_speed <= RPM_THREE_HUNDRED) {
		temp_front_trq = Canobj.front_trq;
	}
	// rear tourqe limit algorithm
	//>700 rpm
	temp_rear_trq = (max_rear_wheel_speed > RPM_SEVEN_HUNDRED && Canobj.rear_trq <= TORQUE_FIFTY)
			    ? Canobj.rear_trq
			    : TORQUE_FIFTY;
	//>600 rpm
	if (max_rear_wheel_speed <= RPM_SEVEN_HUNDRED) {
		temp_rear_trq = (max_rear_wheel_speed > RPM_SIX_HUNDRED && Canobj.rear_trq <= TORQUE_EIGHTY_FIVE)
				    ? Canobj.rear_trq
				    : TORQUE_EIGHTY_FIVE;
	}
	//>500 rpm
	if (max_rear_wheel_speed <= RPM_SIX_HUNDRED) {
		temp_rear_trq = (max_rear_wheel_speed > RPM_FIVE_HUNDRED && Canobj.rear_trq <= TORQUE_HUNDRED)
				    ? Canobj.rear_trq
				    : TORQUE_HUNDRED;
	}
	//>400 rpm
	if (max_rear_wheel_speed <= RPM_FIVE_HUNDRED) {
		temp_rear_trq = (max_rear_wheel_speed > RPM_FOUR_HUNDRED && Canobj.rear_trq <= TORQUE_ONE_TWENTY)
				    ? Canobj.rear_trq
				    : TORQUE_ONE_TWENTY;
	}
	//>300
	if (max_rear_wheel_speed <= RPM_FOUR_HUNDRED) {
		temp_rear_trq = (max_rear_wheel_speed > RPM_THREE_HUNDRED && Canobj.rear_trq <= TORQUE_ONE_FIFTY)
				    ? Canobj.rear_trq
				    : TORQUE_ONE_FIFTY;
	}
	//<300
	if (max_rear_wheel_speed <= RPM_THREE_HUNDRED) {
		temp_rear_trq = Canobj.rear_trq;
	}
	// battery limit
	if (Canobj.voltage <= BATTERY_LOW_VOLTAGE) {
		temp_front_trq = LOW_BATTERY_LIMIT_TORQUE;
		temp_rear_trq = LOW_BATTERY_LIMIT_TORQUE;
	}

	// calculate the front current

	Ival.front_current =
	    ((temp_front_trq / Canobj.voltage) *
	     (1 + (MOTOR_q * MOTOR_q * (temp_front_trq / HUNDRED)) +
	      (max_front_wheel_speed * (ELECTROMAGNETIC_FIELD_FACTOR_b / HUNDRED) *
	       temp_front_trq)));

	// calculate the rear current

	Ival.rear_current =
	    ((temp_rear_trq / Canobj.voltage) *
	     (1 + (MOTOR_q * MOTOR_q * (temp_rear_trq / HUNDRED)) +
	      (max_rear_wheel_speed * (ELECTROMAGNETIC_FIELD_FACTOR_b / HUNDRED) *
	       temp_rear_trq)));

	std::cout << "====Torque Request Values===== \n " << std::endl;
	std::cout << "Front trq : " << Canobj.front_trq << " N-m\t|\t";
	std::cout << "Rear trq  : " << Canobj.rear_trq << " N-m \n\n";
	std::cout << "====Torque Request with Limiter===== \n " << std::endl;
	std::cout << "Front trq Limiter: " << temp_front_trq << " N-m\t|\t";
	std::cout << "Rear trq  Limiter: " << temp_rear_trq << " N-m \n\n";

	std::cout << std::endl;

	std::cout << "=====Wheel Speed Request Values====== \n " << std::endl;
	std::cout << "Front left speed : " << Canobj.fl_wheel_speed << " rpm\t|\t";
	std::cout << "Front right speed: " << Canobj.fr_wheel_speed << " rpm\n\n";
	std::cout << "Front speed LR Max : " << max_front_wheel_speed << " rpm\n\n";
	std::cout << "Rear left speed Req : " << Canobj.rl_wheel_speed << " rpm\t|\t";
	std::cout << "Rear right speed Req : " << Canobj.rr_wheel_speed << " rpm\n\n";
	std::cout << "Rear speed LR Max : " << max_rear_wheel_speed << " rpm\n\n";
	std::cout << std::endl;

	std::cout << "=====Battery Voltage ====== \n " << std::endl;
	std::cout << Canobj.voltage << "v\n"
		  << std::endl;

	std::cout << "==Motor Current Values in mA===" << std::endl;

	std::cout << "Front Motor Current :" << Ival.front_current << "mA"
		  << std::endl;

	std::cout << "Rear Motor Current :" << Ival.rear_current << "mA" << std::endl;

	return Ival;
}
#endif